import { copyFileSync, existsSync, mkdirSync, readFileSync, statSync } from "node:fs";
import { createHash } from "node:crypto";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const EXPECTED_BYTES = 138846;
const EXPECTED_SHA256 =
  "b6cd394564da8e636f8cf445143a39f322749487ad5a9deaa7eeae3c92d539d7";

function sha256(path: string): string {
  return createHash("sha256").update(readFileSync(path)).digest("hex");
}

function main(): void {
  const repoRoot = dirname(fileURLToPath(import.meta.url));
  const source = join(repoRoot, "entry.png");
  const outDir = process.env.OUT_DIR ?? "/output";
  const target = join(outDir, "entry.png");

  if (!existsSync(source)) {
    throw new Error(`source image missing: ${source}`);
  }
  const sourceBytes = statSync(source).size;
  if (sourceBytes !== EXPECTED_BYTES) {
    throw new Error(
      `source byte length mismatch: expected ${EXPECTED_BYTES}, got ${sourceBytes}`,
    );
  }
  if (sha256(source) !== EXPECTED_SHA256) {
    throw new Error("source sha256 mismatch: entry.png is not the expected image");
  }

  mkdirSync(outDir, { recursive: true });
  copyFileSync(source, target);

  const writtenBytes = statSync(target).size;
  if (writtenBytes === 0) {
    throw new Error(`written file is empty: ${target}`);
  }
  if (writtenBytes !== EXPECTED_BYTES) {
    throw new Error(
      `written byte length mismatch: expected ${EXPECTED_BYTES}, got ${writtenBytes}`,
    );
  }
  if (sha256(target) !== EXPECTED_SHA256) {
    throw new Error("written sha256 mismatch: /output/entry.png is corrupted");
  }
  // JPEG magic bytes: a valid JPEG must start with FF D8 FF.
  const header = readFileSync(target).subarray(0, 3);
  if (header[0] !== 0xff || header[1] !== 0xd8 || header[2] !== 0xff) {
    throw new Error(
      `written file is not a valid JPEG (magic bytes ${header.toString("hex")}, expected ffd8ff)`,
    );
  }

  console.log(`wrote ${target} (${writtenBytes} bytes, sha256 verified)`);
}

main();
